function [ AI ] = sparseMul_tzb( A,I )



end

