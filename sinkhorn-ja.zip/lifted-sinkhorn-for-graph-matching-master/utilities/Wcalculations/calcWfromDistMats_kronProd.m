function W = calcWfromDistMats_kronProd(D1,D2,params)
W = kron(D1,D2);
end