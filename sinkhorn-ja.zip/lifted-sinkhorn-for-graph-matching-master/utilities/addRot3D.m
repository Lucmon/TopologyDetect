function addRot3D( )
cameratoolbar('show');
cameratoolbar('SetMode','orbit')
cameratoolbar('SetCoordSys','none')
end

