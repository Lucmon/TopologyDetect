function [ Data ] = parss_data( data,textdata )

Data.label = data;
Data.names = textdata(2:end,1);


end

