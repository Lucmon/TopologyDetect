to run a small example of the algorithm run the script - 
run_example.m
